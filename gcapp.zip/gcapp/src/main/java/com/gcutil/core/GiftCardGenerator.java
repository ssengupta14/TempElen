package com.gcutil.core;

import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.codec.binary.Base32;

public class GiftCardGenerator {

    private AtomicLong sequence;
    private Random random;
    
    // currencies
    public static int USD =0;
    public static int EURO =1;
    public static int INR =2;
    
    Random rand = new Random(3);
    public GiftCardGenerator() {
        // 1325383200000L == 1 Jan 2012
        sequence = new AtomicLong(System.currentTimeMillis() - 1325383200000L);
        random = new SecureRandom();
    }

    public String generateCode() {
        System.out.println(sequence.get());
        byte[] id = new byte[10];
        longTo5ByteArray(sequence.incrementAndGet(), id);
        byte[] rnd = new byte[5];
        random.nextBytes(rnd);
        System.arraycopy(rnd, 0, id, 5, 5);
        /*
        char[] ch =(new Base32().encodeAsString(id)).toCharArray();        
    	StringBuilder str = new StringBuilder();
    	int counter = 0;
    	for(char charac: ch){
    		counter++;    		
    		if(Character.isAlphabetic(charac)){
    			if(Character.isUpperCase(charac)){
    				 int temp = (int)charac;
    			     int temp_integer = 64; //for upper case
    			     if(temp<=90 & temp>=65){
    			    	 str.append(temp-temp_integer);
    			    }
    			}else{
    				int temp = 96; //for lower case
    				if(temp<=122 & temp>=97){
    					 str.append(temp-96);
    				}
    			}
    			
    			
    			
    			
    		}if(Character.isDigit(charac)){
    			str.append(charac);
    		}
    		if(counter%4==0){
    		str.append(" ");	
    		}
    	}
        */
        char[] ch = (new Base32().encodeAsString(id)).toCharArray();
        int counter = 0;
        StringBuilder str = new StringBuilder();
        for(char cha:ch){
        	counter++; 
        	if(counter%4==0){
        		str.append(" ");	
        	}else{
        		str.append(cha);
        	}
        }
        
        return str.toString();
    }

    
    private void longTo5ByteArray(long l, byte[] b) {
        b[0] = (byte) (l >>> 32);
        b[1] = (byte) (l >>> 24);
        b[2] = (byte) (l >>> 16);
        b[3] = (byte) (l >>> 8);
        b[4] = (byte) (l >>> 0);
    }
    
    public String generateScratchCode(){
    	
    	
    	int pick = rand.nextInt(900) + 100;
    	return ""+pick;
    }
    
    public static String generatePurchasedDate(){
    	
    	DateFormat dateFormat = new SimpleDateFormat("MM/yy");
    	Calendar cal = Calendar.getInstance();
    	
    	return dateFormat.format(cal.getTime());
    	
    }
    
    public void generateGiftCard(int templateId, int amount, int currencyCode){
    	GiftCardGenerator gcg = new GiftCardGenerator();
    	ccapplication ccapp = new ccapplication();
    	ccapplication.Card card = ccapp. new Card();
    	card.setCardNumber(gcg.generateCode());
    	card.setPurchaseDate(generatePurchasedDate());
    	card.setScratchCode(gcg.generateScratchCode());
    	card.setCurrencyCode(currencyCode);
    	card.setTemplateId(templateId);
    	card.setAmount(""+amount);
    	ccapp.generateCard(card);
    	
    }
    public static void main(String args[]){
    	GiftCardGenerator gcg = new GiftCardGenerator();
    	ccapplication ccapp = new ccapplication();
    	ccapplication.Card card = ccapp. new Card();
    	card.setCardNumber(gcg.generateCode());
    	card.setPurchaseDate(generatePurchasedDate());
    	card.setScratchCode(gcg.generateScratchCode());
    	card.setTemplateId(3);
    	ccapp.generateCard(card);
    	/*
    	
    	
    	System.out.println("card 1 # ="+gcg.generateCode());
    	System.out.println("card 1 # ="+gcg.generateScratchCode());
    	System.out.println("card 1 # ="+generatePurchasedDate());
    	
    	System.out.println("card 2 # ="+gcg.generateCode());
    	System.out.println("card 2 # ="+gcg.generateScratchCode());
    	System.out.println("card 2 # ="+generatePurchasedDate());
    	
    	System.out.println("card 3 # ="+gcg.generateCode());
    	System.out.println("card 3 # ="+gcg.generateScratchCode());
    	System.out.println("card 3 # ="+generatePurchasedDate());
    	
    	System.out.println("card 4 # ="+gcg.generateCode());
    	System.out.println("card 4 # ="+gcg.generateScratchCode());
    	System.out.println("card 4 # ="+generatePurchasedDate());
    	
    	System.out.println("card 5 # ="+gcg.generateCode());
    	System.out.println("card 5 # ="+gcg.generateScratchCode());
    	System.out.println("card 5 # ="+generatePurchasedDate());
    	
    	*/
    }
}
