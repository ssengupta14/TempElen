package com.gcutil.core;
import com.gcutil.core.GiftCardGenerator;


public class TestGiftCard {
	
	public static void main(String arg[]){
		GiftCardGenerator giftCard = new GiftCardGenerator();
		giftCard.generateGiftCard(2, 20,GiftCardGenerator.USD);
		
		
	}

}
