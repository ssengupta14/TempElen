$(document).ready(function()
	{
		
	$('.audio1').mediaelementplayer({
	features: ['playpause', 'progress']
	});
	
	

});